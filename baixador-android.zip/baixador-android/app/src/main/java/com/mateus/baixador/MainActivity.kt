package com.mateus.baixador

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mateus.baixador.databinding.ActivityMainBinding
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private var motorPronto = false
    private var baixando = false
    private var cancelado = false
    private val processId = "baixador-download"

    // Nome mostrado -> altura máxima do vídeo
    private val qualidades = listOf(
        "Até 1080p" to 1080,
        "720p" to 720,
        "480p" to 480,
        "360p" to 360
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.spinnerQualidade.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            qualidades.map { it.first }
        )

        b.grupoTipo.setOnCheckedChangeListener { _, id ->
            b.spinnerQualidade.visibility = if (id == R.id.radioVideo) View.VISIBLE else View.GONE
        }
        b.botaoColar.setOnClickListener { colar() }
        b.botaoBaixar.setOnClickListener { iniciarDownload() }
        b.botaoCancelar.setOnClickListener { cancelar() }

        tratarIntent(intent)
        prepararMotor()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tratarIntent(intent)
    }

    // ---------- Preparação ----------

    private fun prepararMotor() {
        lifecycleScope.launch {
            mostrarStatus("Preparando o app (só demora na primeira vez)...")
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                }
                motorPronto = true
                atualizarBotoes()
                mostrarStatus("Pronto! Cole uma URL e toque em Baixar.")
            } catch (e: Exception) {
                mostrarStatus("Erro ao preparar o app: ${e.message}")
            }
        }
    }

    // ---------- Entrada da URL ----------

    private fun colar() {
        val cm = getSystemService(ClipboardManager::class.java)
        val texto = cm?.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString()
        val link = texto?.let { extrairUrl(it) }
        if (link != null) {
            b.campoUrl.setText(link)
        } else {
            Toast.makeText(this, "Nenhum link na área de transferência", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tratarIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val texto = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            extrairUrl(texto)?.let { b.campoUrl.setText(it) }
        }
    }

    private fun extrairUrl(texto: String): String? =
        Regex("https?://\\S+").find(texto)?.value

    // ---------- Download ----------

    private fun iniciarDownload() {
        if (!motorPronto || baixando) return
        val url = b.campoUrl.text.toString().trim()
        if (!url.startsWith("http")) {
            Toast.makeText(this, "Cole uma URL válida (começando com http)", Toast.LENGTH_SHORT).show()
            return
        }
        val audio = b.grupoTipo.checkedRadioButtonId == R.id.radioAudio
        val altura = qualidades[b.spinnerQualidade.selectedItemPosition].second

        baixando = true
        cancelado = false
        atualizarBotoes()
        b.barraProgresso.visibility = View.VISIBLE
        b.barraProgresso.isIndeterminate = true
        mostrarStatus("Iniciando download...")

        lifecycleScope.launch {
            val pastaTemp = File(cacheDir, "dl")
            try {
                val salvoEm = withContext(Dispatchers.IO) {
                    pastaTemp.deleteRecursively()
                    pastaTemp.mkdirs()
                    executar(url, audio, altura, pastaTemp)
                    val arquivo = escolherArquivo(pastaTemp)
                        ?: throw IOException("O download terminou, mas nenhum arquivo foi gerado.")
                    salvarNoCelular(arquivo)
                }
                mostrarStatus("Concluído! Salvo em: $salvoEm")
            } catch (e: Exception) {
                mostrarStatus(if (cancelado) "Download cancelado." else erroAmigavel(e))
            } finally {
                withContext(Dispatchers.IO) { pastaTemp.deleteRecursively() }
                baixando = false
                b.barraProgresso.visibility = View.INVISIBLE
                atualizarBotoes()
            }
        }
    }

    private fun executar(url: String, audio: Boolean, altura: Int, pasta: File) {
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("--windows-filenames")
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("-o", "${pasta.absolutePath}/%(title).80s.%(ext)s")

        if (audio) {
            req.addOption("-f", "bestaudio/best")
            req.addOption("-x")
            req.addOption("--audio-format", "mp3")
            req.addOption("--audio-quality", "0")
        } else {
            req.addOption("-f", "bv*+ba/b")
            // Prefere H.264 + AAC (toca em qualquer celular) até a altura escolhida
            req.addOption("-S", "res:$altura,vcodec:h264,acodec:m4a")
            req.addOption("--merge-output-format", "mp4")
        }

        YoutubeDL.getInstance().execute(req, processId) { progresso, eta, _ ->
            runOnUiThread {
                if (progresso >= 0f) {
                    b.barraProgresso.isIndeterminate = false
                    b.barraProgresso.progress = progresso.toInt()
                    val restante = if (eta > 0) " — faltam ${eta}s" else ""
                    mostrarStatus("Baixando... ${progresso.toInt()}%$restante")
                }
            }
        }
    }

    private fun cancelar() {
        if (!baixando) return
        cancelado = true
        YoutubeDL.getInstance().destroyProcessById(processId)
    }

    // ---------- Arquivos ----------

    private fun escolherArquivo(pasta: File): File? =
        pasta.listFiles()
            ?.filter {
                it.isFile && it.length() > 0 &&
                    !it.name.endsWith(".part") &&
                    !it.name.endsWith(".ytdl") &&
                    !it.name.endsWith(".json")
            }
            ?.maxByOrNull { it.length() }

    /** Salva na Galeria (vídeos), em Músicas (áudio) ou em Downloads (outros). */
    private fun salvarNoCelular(arquivo: File): String {
        val ext = arquivo.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"

        val (colecao, pasta) = when {
            mime.startsWith("video") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MOVIES
            mime.startsWith("audio") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_DOWNLOADS
        }

        val valores = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, arquivo.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$pasta/Baixador")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(colecao, valores)
            ?: throw IOException("Não consegui criar o arquivo no celular.")

        contentResolver.openOutputStream(uri)?.use { saida ->
            arquivo.inputStream().use { entrada -> entrada.copyTo(saida) }
        } ?: throw IOException("Não consegui gravar o arquivo no celular.")

        valores.clear()
        valores.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(uri, valores, null, null)

        return "$pasta/Baixador/${arquivo.name}"
    }

    // ---------- Interface ----------

    private fun atualizarBotoes() {
        b.botaoBaixar.isEnabled = motorPronto && !baixando
        b.botaoCancelar.isEnabled = baixando
    }

    private fun mostrarStatus(texto: String) {
        b.textoStatus.text = texto
    }

    private fun erroAmigavel(e: Exception): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("Unsupported URL", true) ->
                "Esse link não é suportado. Confira se é o link direto do vídeo."
            m.contains("Unable to resolve host", true) ||
                m.contains("Network is unreachable", true) ||
                m.contains("timed out", true) ->
                "Sem conexão com a internet. Verifique e tente de novo."
            m.contains("Sign in", true) || m.contains("not a bot", true) ->
                "O site pediu login ou verificação. Tente outro link ou tente de novo mais tarde."
            m.contains("Private video", true) || m.contains("unavailable", true) ->
                "Esse vídeo está privado ou indisponível."
            m.contains("HTTP Error 403", true) || m.contains("HTTP Error 429", true) ->
                "O site bloqueou o acesso. Tente de novo em alguns minutos."
            else -> {
                val ultimaLinha = m.lines().lastOrNull { it.isNotBlank() } ?: "erro desconhecido"
                "Não consegui baixar: ${ultimaLinha.take(300)}"
            }
        }
    }
}
