# Baixador — app Android

Cole uma URL (ou use **Compartilhar** de outro app), escolha **Vídeo MP4** ou **Música MP3** e baixe.
Vídeos vão para a Galeria (pasta Movies/Baixador) e músicas para Músicas (Music/Baixador).

Usa o yt-dlp + FFmpeg embutidos (biblioteca youtubedl-android), que cobrem centenas de sites.
O yt-dlp vem embutido na biblioteca. Para ter uma versão mais nova dele, atualize a versão da biblioteca em `app/build.gradle.kts` e gere o APK de novo.

## Como gerar o APK (passo a passo)

1. No computador, instale o **Android Studio**: https://developer.android.com/studio
2. Descompacte esta pasta. No Android Studio: **File > Open** e escolha a pasta `baixador-android`.
3. Espere a barra de progresso embaixo terminar ("Gradle sync"). A primeira vez demora e baixa bastante coisa.
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Quando terminar, clique em **locate**. O arquivo é `app/build/outputs/apk/debug/app-debug.apk`.
6. Mande o APK para o celular (cabo USB, Google Drive, WhatsApp...) e abra.
   O Android vai pedir para permitir a instalação de apps de fontes desconhecidas — permita.

Dica: conectando o celular por USB com "Depuração USB" ligada, dá para instalar direto pelo botão ▶ (Run).

## Requisitos
- Android 10 ou mais novo (minSdk 29)
- Internet

## Se algo der errado
- **Erro no Gradle Sync**: confira a internet e clique em "Try Again". Se pedir, aceite atualizar o Gradle.
- **Erro de compilação em `execute(...)`**: me mande o erro. A biblioteca muda um pouco entre versões.
  A versão usada está em `app/build.gradle.kts` (0.18.1) e pode haver uma mais nova.
- **Download falha em um site**: pode ser bloqueio do site. Tente de novo mais tarde ou atualize a versão da biblioteca.
- Mantenha o app aberto durante o download (a tela fica ligada enquanto ele está aberto).

## Limitações (sendo honesto)
- Nenhum downloader funciona 100% do tempo: os sites mudam e bloqueiam. O motor atualizado resolve a maioria dos casos.
- Sites com DRM (ex.: Netflix, Spotify) não funcionam.
- Use apenas com conteúdo que você tem direito de baixar. Muitas plataformas proíbem downloads nos termos de uso.
